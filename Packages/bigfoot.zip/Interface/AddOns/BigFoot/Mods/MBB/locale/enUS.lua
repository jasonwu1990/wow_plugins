local L = LibStub("AceLocale-3.0"):NewLocale("MBB","enUS",true)
if not L then return end

L["Minimap ButtonBag"] = true
L["Enable Tooltip"] = true
L["BigFoot Mini map"] = true 
L["Left click to open mini panel"] = true
L["Right click to show dropdown menu"] = true
L["Attach to Minimap"] = true
L["Options"] = true
L["Enable"] = true
L["Enable Mouse Over"] = true;
L["Keep Icon Size"] = true;
L["sec"] = true ;
L["Collapse Timeout:"] = true ;
L["Expand to:"] = true;
L["Left"] = true;
L["Top"] = true;
L["Right"] = true ;
L["Bottom"] = true;
L["Max. Buttons/Line:"] = true;
L["(0=infinity)"] = true;
L["Alt. Expand to:"] = true ;
L["Type \"/mbb <cmd>\" where <cmd> is one of the following:"] = true;
L["  |c00ffffffbuttons|r: Shows a list of all frames in the MBB bar"] = true ;
L["  |c00ffffffreset position|r: resets the position of the MBB minimap button"] = true;
L["  |c00ffffffreset all|r: resets all options"] = true;
L["No errors found!"] = true;